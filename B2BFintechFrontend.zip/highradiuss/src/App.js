
import Headerr from "./components/Headerr"

import { DataGridd } from "./components/DataGridd";
import AdvanceSearch from "./components/advanceSearch";
import React ,{useState} from "react";
import Analayticsview from "./components/analayticsview";
import Search from "./components/search";
import Footer from "./components/footer"
import Predict from "./components/predict";

export default function App() {
  const[tableData,setTableData] =useState([]);

  return (
    < >
      <Headerr/>
      <DataGridd setTableData = {setTableData} tableData = {tableData}/>
      <AdvanceSearch setTableData = {setTableData} tableData = {tableData}/>
      <Analayticsview/>
      <Search setTableData = {setTableData} />
      <Footer/>
      <Predict/>
      <edit/> 
      
    </>
    
  );
}

