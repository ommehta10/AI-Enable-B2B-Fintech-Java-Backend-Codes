import React from 'react'
import axios from 'axios'

function Search(props)
{
    const handleSearch = (e) => {
        axios
          .get(
            `http://localhost:8080/Serrvlet_9/SearchInvoice?&cust_number=${cust_number}`
          )
          .then(function (response) {
            console.log(response);
            props.setTableData(response.data)
          })
          .catch(function (error) {
            console.log(error);
          });
          
      };

    const [cust_number, setCustomerNumber] = React.useState("");
    return (
        <>
        <input
         style={{ 
         padding: "5px",
        border: '1px solid skyblue',
        display: "flex", 
      
        backgroundColor:"#fff",
        
        textAlign:"center",
        position: 'absolute',
        right: 10,
        top: 0,
        left:540
        ,
        height:25,
         borderRadius:10,
        width:150,
        margin:"20.4vh 15vh 0vh 10vh"}} 
       
         type="number" 
         placeholder="Search Customer Id" 
         onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
         onChange={(e) => setCustomerNumber(e.target.value)}
         />
        </>
    );
}
 export default Search;