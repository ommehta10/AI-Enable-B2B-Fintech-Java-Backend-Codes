import "./headerr.css";
import React  from 'react'
import {StyleSheet,View} from 'react-native'
import image from "./Group 20399.svg";
import logo from "./logo.svg";
import AddModal from "./AddModal";
import Edit from "./editmodel";
import DeleteModal from "./deletemodal";

import Refresh from "./Refresh";


export default function Headerr() {
  return (
    <div className="App">
      <div className="logo-flex">
      <View style={styles.container_header}>
        <View style={styles.square_abc}>
        <img src={image} alt="abc-products" className="abc" />
        </View>
        <View style={styles.square}>
        <img src={logo} alt="hrc-logo" className="hrc" />
        </View>
      </View>
      </div>
      <div className="header-part-two">
        <View style = {styles.container}>
        <View style={styles.square_one}>
        <div className="btn-grp">
          
        <Refresh/>
        </div>
        </View>
        <View style={styles.search_square}>
        </View>
        <View style={styles.square_three}>
        <div className="btn-grp2">
          <AddModal /> 
          <Edit/>
          <DeleteModal/>
         
        </div>
        </View>
        </View> 
      </div>
    </div>
  );
}

const styles = StyleSheet.create({
  container_header: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    flexDirection: "row"
  },
  square: {
    backgroundColor: "#2d4250",
    width: 500,
    height: 100,
    margin: 4,
    display:"flex",
    alignItems:"center",
    right:"250px",
   justifyContent:"center"
  },
  square_abc: {
    backgroundColor: "#2d4250",
    width: 500,
    height: 100,
    margin: 4,
    display:"flex",
    justifyContent: "center",
    right:"270px"
  },
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center", 
    flexDirection: "row"
  },
  square_one: {
    backgroundColor: "#283d4a",
    width: 610,
    height: 36.5,
    margin: 4,
    marginRight: 40,
  },
  search_square: {
    backgroundColor: "#283d4a",
    width: 180,
    height: 40,
    margin: 4,
    marginRight: 60,
    right:60
  },
  square_three: {
    backgroundColor: "#283d4a",
    width: 400,
    height: 36.5,
    margin: 4,
  },
});