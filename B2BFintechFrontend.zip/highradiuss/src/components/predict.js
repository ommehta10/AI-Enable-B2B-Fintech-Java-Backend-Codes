import React from 'react'
import Button from '@material-ui/core/Button';

import axios from 'axios';
function Predict()
{
    const handlepredict = (e,) => {
        axios
          .get(
            `http://127.0.0.1:5000/get_prediction?&doc_id=${doc_id}`
          )
          .then(function (response) {
            console.log(response,);
            // props.setTableData(response.data)
          })
          .catch(function (error) {
            console.log(error);
          });
          
      };




    const [doc_id, setDocumentId] = React.useState("");

  return (
 <Button variant="contained" color="secondary" onClick={handlepredict} style={{
  borderRadius: "6",
  padding: "4px",
 border: '1px solid skyblue',
 display: "flex", 
 backgroundColor:"#273d49",
 color:'white',
 textAlign:"center",
 position: 'absolute',
 letterSpacing:2,
 
 top: 0,
 left:1
 ,
 width:"120px",
  margin:"20.4vh 15vh 0vh 8vh",



     
    }} onChange={(e) => setDocumentId(e.target.value)}
    >

        PREDICT
    </Button>


  )
}

export default Predict;