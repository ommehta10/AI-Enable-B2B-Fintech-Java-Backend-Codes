import React from 'react';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import TextField from '@mui/material/TextField';
import Box from '@mui/material/Box';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import axios from 'axios';

const useStyles = makeStyles(theme => ({
    modal: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        
      
    },
    paper: {
        backgroundColor: "#2d4250",
        border: '1px solid #000',
        borderRadius: '15px',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
}));
export default function AdvanceSearch(props) {
  
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    const [cust_number, setCustomerNumber] = React.useState("");
  const [doc_id, setDocumentId] = React.useState("");
  const [invoice_id, setInvoiceId] = React.useState("");
  const [buisness_year, setBuisnessYear] = React.useState("");
    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const handleEdit = (e) => {
      e.preventDefault();
      axios
        .get(
          `http://localhost:8080/Serrvlet_9/AdvanceSearch?&doc_id=${doc_id}&cust_number=${cust_number}&buisness_year=${buisness_year}&invoice_id=${invoice_id}`
        )
        .then(function (response) {
          console.log(response);
          props.setTableData(response.data)
          console.log(props.tableData)


        })
        .catch(function (error) {
          console.log(error);
        });
        setOpen(false);
    };
    return (
        <div > 
          

            <Button  variant="contained" color="#fff" onClick={handleOpen} style={{
                borderRadius: "6",
                 padding: "5px",
                border: '1px solid skyblue',
                display: "flex", 
                backgroundColor:"#273d49",
                color:'white',
                textAlign:"center",
                position: 'absolute',
                right: 10,
                top: 0,
                left:260
                ,
                margin:"20.4vh 15vh 0vh 10vh",
                fontSize:"13px",
  
  fontFamily:"sans-serif",
 
  fontweight:"bold",
  width:"150px"
                
           
            }}>
                ADVANCE SEARCH
            </Button>
          
            <Modal
                aria-labelledby="transition-modal-title"
                aria-describedby="transition-modal-description"
                className={classes.modal}
                open={open}
                onClose={handleClose}
                closeAfterTransition
                BackdropComponent={Backdrop}
                BackdropProps={{
                    timeout: 500,
                }}
            >
                <Fade in={open}>
                    <div className={classes.paper}>
                        <h2 style={{color: 'white'}}>Adavance Search</h2>
                        <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          p: 1,
          m: 1,
          bgcolor: 'background.paper',
          maxWidth: "56ch",
          borderRadius: 3,
          alignContent: 'flex-start',
        }}
      >
        <TextField
          id="outlined-multiline-flexible"
          label="Document Id"
          multiline
          maxRows={4}
          value={doc_id}
                onChange={(e) => setDocumentId(e.target.value)}
          margin='normal'
          variant="filled"
        />&nbsp;&nbsp;&nbsp;&nbsp;
        <TextField
          id="outlined-multiline-flexible"
          label="Invoice Id"
          multiline
          value={invoice_id}
          onChange={(e) => setInvoiceId(e.target.value)}
          maxRows={4}
          variant="filled"
          margin='normal'
        />&nbsp;&nbsp;&nbsp;&nbsp;
       <TextField
          id="outlined-multiline-flexible"
          label="Customer Number"
          multiline
          maxRows={4}
          value={cust_number}
          onChange={(e) => setCustomerNumber(e.target.value)}          margin='normal'
          variant="filled"
        />&nbsp;&nbsp;&nbsp;&nbsp;
      <TextField
        id="outlined-multiline-flexible"
        label="Business Year"
        multiline
        value={buisness_year}
        onChange={(e) => setBuisnessYear(e.target.value)}
        maxRows={4}
        variant="filled"
        margin='normal'
      />&nbsp;&nbsp;&nbsp;&nbsp;
        <Button style={{width: '210px', border: '1px solid #2d4250', backgroundColor: '#2d4250', color: 'white'}} onClick ={handleEdit}>Search</Button>&nbsp;&nbsp;
        <Button style={{width: '210px', border: '1px solid #2d4250', backgroundColor: '#2d4250', color: 'white'}}onClick ={handleClose}>Cancel</Button>  
      </Box>
                    </div>
                </Fade>
            </Modal> 
            </div>
    );
}