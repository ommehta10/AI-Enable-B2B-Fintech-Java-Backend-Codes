
import React from 'react';
import Button from '@material-ui/core/Button';
import { makeStyles } from '@material-ui/core/styles';
import Modal from '@material-ui/core/Modal';
import Box from '@mui/material/Box';
import Backdrop from '@material-ui/core/Backdrop';
import Fade from '@material-ui/core/Fade';
import DialogContent from '@mui/material/DialogContent'; 
import DialogContentText from '@mui/material/DialogContentText'; 
import { RowSelected } from './DataGridd';
import axios from 'axios';
const useStyles = makeStyles(theme => ({
    modal: {
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
    },
    paper: {
        backgroundColor: "#2d4250",
        border: '1px solid #000',
        borderRadius: '15px',
        boxShadow: theme.shadows[5],
        padding: theme.spacing(2, 4, 3),
    },
}));
//const [first, setfirst] = useState('')
export default function DeleteModal() {
    const classes = useStyles();
    const [open, setOpen] = React.useState(false);
    const handleOpen = () => {
        setOpen(true);
    };
    const handleClose = () => {
        setOpen(false);
    };
    const Delete1 = async (RowSelected) => {
        console.log(RowSelected);
        console.log("Successfully deleted");


        await axios.post(
          "http://localhost:8080/Serrvlet_9/DeleteInvoice?sl_no="+
          RowSelected,
        
            {header:('Access-Control-Allow-Origin: *')}
        );
        setOpen(false);
      };

  
   
    const handleCloseDelete = () => {
      
          Delete1(RowSelected());
        };
    return (
        <div>
            <Button variant="contained" color="secondary" onClick={handleOpen} style={{
                borderRadius: 6,
                padding: "5px",
                border: '1px solid skyblue'
            }}>
                DELETE
            </Button>
            <Modal
                aria-labelledby="transition-modal-title"
                aria-describedby="transition-modal-description"
                className={classes.modal}
                open={open}
                onClose={handleClose}
                closeAfterTransition
                BackdropComponent={Backdrop}
                BackdropProps={{
                    timeout: 500,
                }}
            >
                <Fade in={open}>
                    <div className={classes.paper}>
                        <h2 style={{color: 'white'}}>Delete</h2>
                        <Box
        sx={{
          display: 'flex',
          flexWrap: 'wrap',
          p: 1,
          m: 1,
          bgcolor: 'background.paper',
          maxWidth: 870,
          borderRadius: 3,
          alignContent: 'flex-start',
        }}
      >
      <DialogContent> 
          <DialogContentText > 
            <Box> 
              Are you sure you want to delete these records[s] ? 
            </Box> 
          </DialogContentText> 
        </DialogContent>
        <Button style={{width: '49%', border: '1px solid #2d4250', backgroundColor: '#2d4250', color: 'white'}}onClick={handleCloseDelete}>Delete</Button>&nbsp;&nbsp;
        <Button style={{width: '49%', border: '1px solid #2d4250', backgroundColor: '#2d4250', color: 'white'}}onClick ={handleClose}>Cancel</Button>  
      </Box>
                    </div>
                </Fade>
            </Modal>
        </div>
        );
    }