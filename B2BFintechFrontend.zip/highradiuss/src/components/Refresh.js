import React from 'react' 
import RefreshIcon from '@mui/icons-material/Refresh'; 
import Button from '@material-ui/core/Button'; 
 
function Refresh(){ 
 
    function refreshPage() { 
        window.location.reload(false); 
      } 
 
    return( 
        <> 
            <Button style={{border:"1px solid #14AFF1",height:"2rem",color:"#14AFF1",margin:"15.4vh 0vh 4vh 67vh", bottom:"100px",right:"100px",width:50}} onClick={refreshPage}><RefreshIcon/></Button> 
        </> 
    ); 
} 
 
export default Refresh;