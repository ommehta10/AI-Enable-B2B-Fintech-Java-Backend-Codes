import React from 'react';
import CopyrightIcon from '@mui/icons-material/Copyright';
import { Typography} from '@material-ui/core';


const styles={
  color:'white',
padding: '0vh 0vh 2vh 70vh',
  backgroundcolor: "#273d49",
}


function Footer() {


  return (
      <div style={{backgroundColor:"#273d49" }}>
            <Typography style={styles}>
        <span style={{ color:'blue' }} >Privacy Policy</span> <span>| <CopyrightIcon/> </span> 2020 HighRadius Corporation. All rights reserved.
      </Typography>

      </div>
    
  );
}

export default (Footer);